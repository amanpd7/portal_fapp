import React, { useState } from "react";
import "./merged_styles.css"; // Importing the CSS file
import BosseLogo from "./images/bosse.jpg"; // Import the BOSSE logo

const SubjectSelectionForm = () => {
  const [languageSubjects, setLanguageSubjects] = useState([]);
  const [nonLanguageSubjects, setNonLanguageSubjects] = useState([]);
  const [vocationalSubjects, setVocationalSubjects] = useState([]);

  const languageOptions = [
    "HINDI",
    "ENGLISH",
    "URDU",
    "BENGALI",
    "PUNJABI",
    "ASSAMESE",
    "NEPALI",
    "ODIA",
    "KANNADA",
    "MALAYALAM",
    "TAMIL",
    "TELUGU",
  ];

  const nonLanguageOptions = [
    "MATHEMATICS",
    "SCIENCE AND TECHNOLOGY (P)",
    "SOCIAL SCIENCE",
    "ECONOMICS",
    "BUSINESS STUDIES",
    "PSYCHOLOGY (P)",
    "INDIAN CULTURE AND HERITAGE",
    "ACCOUNTANCY",
    "HOME SCIENCE & HUMAN ECOLOGY (P)",
  ];

  const vocationalOptions = [
    "CARPENTRY (P)",
    "SOLAR ENERGY TECHNICIAN (P)",
    "BIO GAS TECHNICIAN (P)",
    "LAUNDRY SERVICES (P)",
    "BAKERY AND CONFECTIONERY (P)",
    "WELDING TECHNOLOGY (P)",
    "DATA ENTRY OPERATIONS (P)",
    "PAINTING & DRAWING (P)",
  ];

  const handleLanguageChange = (subject) => {
    setLanguageSubjects((prev) =>
      prev.includes(subject)
        ? prev.filter((s) => s !== subject)
        : [...prev, subject]
    );
  };

  const handleNonLanguageChange = (subject) => {
    setNonLanguageSubjects((prev) =>
      prev.includes(subject)
        ? prev.filter((s) => s !== subject)
        : [...prev, subject]
    );
  };

  const handleVocationalChange = (subject) => {
    setVocationalSubjects((prev) =>
      prev.includes(subject)
        ? prev.filter((s) => s !== subject)
        : [...prev, subject]
    );
  };

  return (
    <div className="form-container">
      <div className="header">
        <img src={BosseLogo} alt="BOSSE Logo" className="bosse-logo" />
        <h2 className="form-title">Select Subject</h2>
      </div>
      <p className="form-notes">
        <b>Notes:</b>
        <br />
        (P) denotes that Subject includes practical.
        <br />
        You can select Minimum 1 & Maximum 2 in Language Subjects.
        <br />
        You can select Minimum 2 & Maximum 4 in Non-Language Subjects.
        <br />
        You can select Maximum 2 in Vocational Subjects.
      </p>

      <div className="subject-container">
        <div className="subject-category language-subjects">
          <h3>Language Subject</h3>
          {languageOptions.map((subject) => (
            <div key={subject} className="subject-option">
              <input
                type="checkbox"
                checked={languageSubjects.includes(subject)}
                onChange={() => handleLanguageChange(subject)}
                disabled={
                  !languageSubjects.includes(subject) &&
                  languageSubjects.length >= 2
                }
              />
              <label className="subject-label">{subject}</label>
            </div>
          ))}
        </div>

        <div className="subject-category non-language-subjects">
          <h3>Non-Language Subject</h3>
          {nonLanguageOptions.map((subject) => (
            <div key={subject} className="subject-option">
              <input
                type="checkbox"
                checked={nonLanguageSubjects.includes(subject)}
                onChange={() => handleNonLanguageChange(subject)}
                disabled={
                  !nonLanguageSubjects.includes(subject) &&
                  nonLanguageSubjects.length >= 4
                }
              />
              <label className="subject-label">{subject}</label>
            </div>
          ))}
        </div>

        <div className="subject-category vocational-subjects">
          <h3>Vocational Subject</h3>
          {vocationalOptions.map((subject) => (
            <div key={subject} className="subject-option">
              <input
                type="checkbox"
                checked={vocationalSubjects.includes(subject)}
                onChange={() => handleVocationalChange(subject)}
                disabled={
                  !vocationalSubjects.includes(subject) &&
                  vocationalSubjects.length >= 2
                }
              />
              <label className="subject-label">{subject}</label>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default SubjectSelectionForm;
