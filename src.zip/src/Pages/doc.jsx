import React, { useState } from "react";
import "./merged_styles.css"; // Import the CSS for styling
import bosseLogo from "./images/bosse.jpg"; // Import the logo

const DocForm = () => {
  const [documents, setDocuments] = useState([
    { title: "X", yearOfPassing: "", file: null, fileName: "" },
    { title: "XII", yearOfPassing: "", file: null, fileName: "" },
    { title: "AADHAR", yearOfPassing: "", file: null, fileName: "" },
  ]);

  const handleFileChange = (index, e) => {
    const file = e.target.files[0];
    const newDocuments = [...documents];
    newDocuments[index].file = file;
    newDocuments[index].fileName = file ? file.name : "";
    setDocuments(newDocuments);
  };

  const handleYearOfPassingChange = (index, e) => {
    const newDocuments = [...documents];
    newDocuments[index].yearOfPassing = e.target.value;
    setDocuments(newDocuments);
  };

  return (
    <div className="form-container">
      <div className="logo-section">
        <img src={bosseLogo} alt="BOSSE Logo" className="logo" />
      </div>
      <div className="section-header">
        <h2>Student Details</h2>
      </div>
      <div className="student-details">
        <img src="path-to-image.jpg" alt="Student" className="student-photo" />
        <div className="student-info">
          <div>
            <label>Batch</label>
            <input type="text" value="BLOCK-2 2024 (M-24)" readOnly />
          </div>
          <div>
            <label>Course</label>
            <input type="text" value="SECONDARY" readOnly />
          </div>
          <div>
            <label>Student's Name</label>
            <input type="text" value="S AASAITHAMBI" readOnly />
          </div>
          <div>
            <label>Father's Name</label>
            <input type="text" value="M SUBRAMANI" readOnly />
          </div>
        </div>
      </div>

      <div className="section-header">
        <h2>Details Of Educational Qualifications</h2>
      </div>
      <div className="education-details">
        {documents.map((doc, index) => (
          <div key={index} className="doc-row">
            <div className="doc-info">
              <input type="text" value={doc.title} readOnly />
            </div>
            <div className="doc-info">
              <input
                type="text"
                placeholder="Year of Passing"
                value={doc.yearOfPassing}
                onChange={(e) => handleYearOfPassingChange(index, e)}
              />
            </div>
            <div className="doc-upload">
              <input
                type="file"
                onChange={(e) => handleFileChange(index, e)}
                accept=".pdf,.jpg,.jpeg,.png"
              />
              <span>{doc.fileName}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="button-container">
        <button className="back-button">Back</button>
        <button className="next-button">Next</button>
      </div>
    </div>
  );
};

export default DocForm;
