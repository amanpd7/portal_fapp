import React, { useState } from "react";
import { CountryDropdown, RegionDropdown } from "react-country-region-selector";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "./merged_styles.css";
import logo from "./images/bosse.jpg"; // Import the logo

const Form = () => {
  const [country, setCountry] = useState("");
  const [region, setRegion] = useState("");
  const [dob, setDob] = useState(null);

    const [day, setDay] = useState("");
    const [month, setMonth] = useState("");
    const [year, setYear] = useState("");
  
    const days = Array.from({ length: 31 }, (_, i) => i + 1);
    const months = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];
    const currentYear = new Date().getFullYear();
    const years = Array.from({ length: 100 }, (_, i) => currentYear - i);

  const [educationDetails, setEducationDetails] = useState({
    yearOfPassing: "",
    board: "",
    rollNumber: "",
    registrationNumber: "",
  });

  const [selectedImage, setSelectedImage] = useState(null);
  const [imageError, setImageError] = useState("");

  const [subjects, setSubjects] = useState([
    { subject: "", totalMarks: "", marksObtained: "", percentage: "" },
  ]);

  const handleEducationDetailsChange = (e) => {
    setEducationDetails({
      ...educationDetails,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubjectChange = (index, e) => {
    const values = [...subjects];
    values[index][e.target.name] = e.target.value;

    // Automatically calculate percentage
    if (e.target.name === "marksObtained" || e.target.name === "totalMarks") {
      const totalMarks = values[index].totalMarks;
      const marksObtained = values[index].marksObtained;
      if (totalMarks && marksObtained) {
        values[index].percentage = ((marksObtained / totalMarks) * 100).toFixed(
          2
        );
      } else {
        values[index].percentage = "";
      }
    }

    setSubjects(values);
  };

  const addSubjectRow = () => {
    setSubjects([
      ...subjects,
      { subject: "", totalMarks: "", marksObtained: "", percentage: "" },
    ]);
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 1024 * 1024) {
        // 1MB = 1024 * 1024 bytes
        setImageError("Image size should be less than 1MB");
        setSelectedImage(null);
      } else {
        setSelectedImage(URL.createObjectURL(file));
        setImageError("");
      }
    }
  };

  return (
    <div className="form-container">
      <div className="logo-section">
        <img src={logo} alt="Bosse Logo" className="logo" />
      </div>
      <form>
        {/* Student's Photo */}
        <div className="photo-section">
          <label>Student's Photo</label>
          <input type="file" accept="image/*" onChange={handleImageChange} />
          {selectedImage && (
            <img src={selectedImage} alt="Selected" className="image-preview" />
          )}
          {imageError && <p style={{ color: "red" }}>{imageError}</p>}
          <p>Note: The size of the photo should be less than 1MB</p>
        </div>

        {/* Details Section */}
        <div className="details-container">
          <div className="details-column">
            <h3>Details</h3>
            <label>Admission Mode *</label>
            <select required>
              <option value="fresh">FRESH</option>
              <option value="transfer">TRANSFER</option>
            </select>

            <label>Admission Session *</label>
            <select required>
              <option value="BLOCK-1 2024 (M-24)">BLOCK-1 2024 (M-24)</option>
              <option value="BLOCK-2 2024 (M-24)">BLOCK-2 2024 (M-24)</option>
            </select>

            <label>Course (Applying for) *</label>
            <select required>
              <option value="secondary">SECONDARY</option>
              <option value="higher-secondary">HIGHER SECONDARY</option>
            </select>

            <label>Student's Name *</label>
            <div className="name-input">
              <select required>
                <option value="mr">Mr.</option>
                <option value="ms">Ms.</option>
                <option value="mrs">Mrs.</option>
              </select>
              <input type="text" required />
            </div>

            <label>Father's Name *</label>
            <input type="text" required />

            <label>Mother's Name *</label>
            <input type="text" required />

            <label>Gender *</label>
            <select required>
              <option value="male">MALE</option>
              <option value="female">FEMALE</option>
              <option value="other">OTHERS</option>
            </select>
            
            <label>Date of Birth *</label>
              <div style={{ display: "flex", gap: "10px" }}>
                <select value={day} onChange={(e) => setDay(e.target.value)} required>
                <option value="" disabled>Select Day</option>
                {days.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
                </select>

                <select value={month} onChange={(e) => setMonth(e.target.value)} required>
                  <option value="" disabled>Select Month</option>
                  {months.map((m, i) => (
                    <option key={i} value={i + 1}>{m}</option>
                  ))}
                </select>

                <select value={year} onChange={(e) => setYear(e.target.value)} required>
                  <option value="" disabled>Select Year</option>
                  {years.map((y) => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>

            <label>Category *</label>
            <select required>
              <option value="gen">GEN</option>
              <option value="obc-a">OBC</option>
              <option value="sc">SC</option>
              <option value="st">ST</option>

            </select>
          </div>

          <div className="details-column">
            <h3>Details</h3>
            <label>Permanent Address *</label>
            <div className="address-input">
              <input type="text" required />
            </div>

            <label>Country *</label>
            <CountryDropdown
              value={country}
              onChange={(val) => setCountry(val)}
              required
            />

            <label>State *</label>
            <RegionDropdown
              country={country}
              value={region}
              onChange={(val) => setRegion(val)}
              required
            />

            <label>City *</label>
            <input type="text" required />

            <label>Pin Code *</label>
            <input type="text" required />

            <label>Contact No. *</label>
            <input type="tel" required />

            <label>Email Address *</label>
            <input type="email" required />

            <label>Aadhar No.</label>
            <input type="text" />
          </div>
        </div>

        {/* Educational Qualifications Section */}
        <div className="education-section">
          <h3>Details Of Educational Qualifications</h3>

          {/* Static Fields */}
          <div className="qualification-row">
            <label>Year of Passing:</label>
            <input
              type="number"
              name="yearOfPassing"
              value={educationDetails.yearOfPassing}
              onChange={handleEducationDetailsChange}
              required
            />

            <label>Board:</label>
            <input
              type="text"
              name="board"
              value={educationDetails.board}
              onChange={handleEducationDetailsChange}
              required
            />

            <label>Roll Number:</label>
            <input
              type="text"
              name="rollNumber"
              value={educationDetails.rollNumber}
              onChange={handleEducationDetailsChange}
              required
            />

            <label>Registration Number:</label>
            <input
              type="text"
              name="registrationNumber"
              value={educationDetails.registrationNumber}
              onChange={handleEducationDetailsChange}
              required
            />
          </div>
        </div>
        <div className="button-container">
          <button type="reset" className="reset-button">
            Reset
          </button>
          <button type="submit" className="next-button">
            Next
          </button>
        </div>
      </form>
    </div>
  );
};

export default Form;
